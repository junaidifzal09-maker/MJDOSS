import React from 'react';
import { modules } from '../data/modules';
import { useAuth } from '../auth/AuthProvider';
import NotificationBell from './NotificationBell';

export default function Layout({ current, setCurrent, children }) {
  const { profile, signOut } = useAuth();
  const role = profile?.role_name || 'Staff/User';
  const visible = Object.entries(modules).filter(([,m]) => m.roles.includes(role));
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="logo">MJ-DOS <span>ERP</span></div>
      <div className="role-pill">{role}</div>
      <nav>{visible.map(([key, m]) => <button key={key} className={current===key?'active':''} onClick={() => setCurrent(key)}>{m.label}</button>)}</nav>
    </aside>
    <section className="main-panel">
      <header className="topbar">
        <div><h2>{modules[current]?.label || 'Dashboard'}</h2><p>{profile?.full_name || profile?.email || 'Authenticated user'}</p></div>
        <div className="topbar-actions"><NotificationBell /><button className="secondary" onClick={signOut}>Sign out</button></div>
      </header>
      {children}
    </section>
  </div>
}
