import React, { useEffect, useMemo, useState } from 'react';
import { supabase } from '../lib/supabase';
import { tableColumns } from '../data/modules';
import { useAuth } from '../auth/AuthProvider';

function titleCase(s){return s.replaceAll('_',' ').replace(/\b\w/g, c=>c.toUpperCase())}

export default function ModuleTable({ table }) {
  const columns = tableColumns[table] || [];
  const { profile } = useAuth();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [form, setForm] = useState({});
  const [error, setError] = useState('');

  useEffect(() => { loadRows(); }, [table]);

  async function loadRows() {
    setLoading(true);
    let q = supabase.from(table).select('*').order('created_at', { ascending: false }).limit(100);
    if (!['audit_log','roles','authority_matrix','users'].includes(table)) q = q.eq('archived', false);
    const { data, error } = await q;
    if (error) setError(error.message); else setRows(data || []);
    setLoading(false);
  }

  const filtered = useMemo(() => rows.filter(r => JSON.stringify(r).toLowerCase().includes(query.toLowerCase())), [rows, query]);

  async function createRecord(e) {
    e.preventDefault();
    setError('');
    const payload = { ...form, created_by: profile?.id || null };
    const { error } = await supabase.from(table).insert(payload);
    if (error) setError(error.message); else { setForm({}); await loadRows(); }
  }

  async function archiveRecord(row) {
    const { error } = await supabase.from(table).update({ archived: true, status: 'Archived' }).eq('id', row.id);
    if (error) setError(error.message); else await loadRows();
  }

  return <div className="stack">
    <div className="section">
      <div className="toolbar"><input placeholder={`Search ${table}...`} value={query} onChange={e=>setQuery(e.target.value)} /><button className="secondary" onClick={loadRows}>Refresh</button></div>
      {error && <div className="error">{error}</div>}
      {loading ? <div className="empty">Loading...</div> : <table><thead><tr>{columns.map(c=><th key={c}>{titleCase(c)}</th>)}<th>Actions</th></tr></thead><tbody>{filtered.map(row=><tr key={row.id}>{columns.map(c=><td key={c}>{String(row[c] ?? '')}</td>)}<td>{!['audit_log','roles','authority_matrix','users'].includes(table) ? <button className="danger" onClick={()=>archiveRecord(row)}>Archive</button> : <span className="muted">Read only</span>}</td></tr>)}</tbody></table>}
    </div>
    <div className="section">
      <h3>Add Record</h3>
      <form className="form" onSubmit={createRecord}>{columns.filter(c=>!['created_at'].includes(c)).slice(0,8).map(c=><label key={c}>{titleCase(c)}<input value={form[c] || ''} onChange={e=>setForm({...form,[c]:e.target.value})} /></label>)}<button className="primary">Save with audit</button></form>
    </div>
  </div>
}
