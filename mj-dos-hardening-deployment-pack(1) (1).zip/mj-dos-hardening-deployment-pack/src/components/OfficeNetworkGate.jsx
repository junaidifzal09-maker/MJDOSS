import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../auth/AuthProvider';

export default function OfficeNetworkGate({ children }) {
  const { profile } = useAuth();
  const [state, setState] = useState({ loading: true, allowed: true, message: '' });

  useEffect(() => {
    let active = true;
    async function check() {
      if (!profile || profile.ip_exempt) return setState({ loading: false, allowed: true, message: '' });
      const { data, error } = await supabase.functions.invoke('office-network', { body: { user_id: profile.id } });
      if (!active) return;
      if (error) return setState({ loading: false, allowed: false, message: 'Office network validation failed. Ask Admin to verify Edge Function deployment.' });
      setState({ loading: false, allowed: !!data?.allowed, message: data?.message || '' });
    }
    check();
    return () => { active = false; };
  }, [profile]);

  if (state.loading) return <div className="section">Validating office network...</div>;
  if (!state.allowed) return <div className="section error"><b>Access restricted.</b><p>{state.message || 'Employees must use the approved office network.'}</p></div>;
  return children;
}
