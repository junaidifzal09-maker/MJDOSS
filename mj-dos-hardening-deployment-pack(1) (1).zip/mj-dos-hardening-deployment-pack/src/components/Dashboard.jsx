import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

const kpis = [
  ['approvals','Pending Approvals'],['invoices','Invoices'],['dispatch','Dispatch Records'],['compliance','Compliance Items'],['attendance','Attendance Records'],['tasks','Open Tasks']
];

export default function Dashboard() {
  const [counts, setCounts] = useState({});
  useEffect(() => { loadCounts(); }, []);
  async function loadCounts() {
    const next = {};
    for (const [table] of kpis) {
      const { count } = await supabase.from(table).select('*', { count: 'exact', head: true }).eq('archived', false);
      next[table] = count || 0;
    }
    setCounts(next);
  }
  return <div className="grid cards">
    {kpis.map(([table,label]) => <div className="card" key={table}><div className="metric">{counts[table] ?? '—'}</div><div className="label">{label}</div></div>)}
    <div className="section full"><b>Control Rule:</b> Request → Verification → Approval → Execution → Audit Log → Report.</div>
  </div>
}
