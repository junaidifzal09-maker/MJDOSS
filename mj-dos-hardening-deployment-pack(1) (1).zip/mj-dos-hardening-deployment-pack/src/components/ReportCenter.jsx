import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../auth/AuthProvider';

export default function ReportCenter() {
  const { profile } = useAuth();
  const [report, setReport] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => { load(); }, []);

  async function load() {
    setError('');
    const rpc = profile?.role_name === 'CFO' ? 'get_cfo_report' : 'get_ceo_report';
    const { data, error } = await supabase.rpc(rpc);
    if (error) setError(error.message); else setReport(data || {});
  }

  return <div className="stack">
    <div className="section"><h3>Executive Reports</h3><p className="muted">Role-safe report output. P&L access remains restricted by database policy, not by frontend confidence theatre.</p><button className="secondary" onClick={load}>Refresh</button> <button className="secondary" onClick={() => window.print()}>Print</button>{error && <div className="error">{error}</div>}</div>
    {report && <div className="grid cards">{Object.entries(report).map(([k,v]) => <div className="card" key={k}><div className="metric">{typeof v === 'number' ? v.toLocaleString() : String(v ?? '—')}</div><div className="label">{k.replaceAll('_',' ')}</div></div>)}</div>}
  </div>;
}
