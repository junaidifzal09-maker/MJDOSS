import React from 'react';
import { ShieldCheck } from 'lucide-react';
import { useAuth } from '../auth/AuthProvider';

export default function Login() {
  const { signInWithGoogle } = useAuth();
  return <main className="login-shell">
    <section className="login-card">
      <div className="brand-mark"><ShieldCheck size={42}/></div>
      <h1>MJ-DOS ERP</h1>
      <p className="muted">Production control system for MJ Agro Trading (Pvt) Ltd.</p>
      <button className="primary wide-btn" onClick={signInWithGoogle}>Continue with Google</button>
      <div className="policy-box">
        <b>Access Policy</b>
        <p>Only approved Google accounts can access this system. Employees must use the approved office network. CEO/Admin access may be exempted as configured in the authority matrix.</p>
      </div>
    </section>
  </main>
}
