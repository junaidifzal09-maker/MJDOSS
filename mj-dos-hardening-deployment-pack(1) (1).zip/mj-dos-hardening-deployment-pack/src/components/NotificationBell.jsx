import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../auth/AuthProvider';

export default function NotificationBell() {
  const { profile } = useAuth();
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!profile?.id) return;
    load();
    const channel = supabase.channel(`notifications-${profile.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications', filter: `user_id=eq.${profile.id}` }, load)
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [profile?.id]);

  async function load() {
    const { data } = await supabase.from('notifications').select('*').eq('user_id', profile.id).order('created_at', { ascending: false }).limit(10);
    setItems(data || []);
  }

  async function markRead(id) {
    await supabase.from('notifications').update({ is_read: true }).eq('id', id);
    load();
  }

  const unread = items.filter(i => !i.is_read).length;
  return <div className="notification-wrap">
    <button className="secondary" onClick={() => setOpen(!open)}>🔔 {unread ? <b>{unread}</b> : null}</button>
    {open && <div className="notification-menu">
      {items.length === 0 && <p className="muted">No notifications.</p>}
      {items.map(n => <button key={n.id} className={n.is_read ? 'notification read' : 'notification unread'} onClick={() => markRead(n.id)}>
        <strong>{n.title}</strong><span>{n.message}</span><small>{new Date(n.created_at).toLocaleString()}</small>
      </button>)}
    </div>}
  </div>;
}
