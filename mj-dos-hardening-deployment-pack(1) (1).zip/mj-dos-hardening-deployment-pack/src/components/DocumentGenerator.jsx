import React, { useState } from 'react';
import { generateCorporateDocument, downloadTextFile } from '../services/documentGenerators';
import { supabase } from '../lib/supabase';
import { useAuth } from '../auth/AuthProvider';

export default function DocumentGenerator() {
  const { profile } = useAuth();
  const [form, setForm] = useState({ type: 'board_resolution', subject: '', body: '', signatory: '' });
  const [message, setMessage] = useState('');

  async function createDraft() {
    const doc = generateCorporateDocument(form);
    downloadTextFile(`${doc.ref}.txt`, doc.content);
    await supabase.from('documents').insert({
      ref_no: doc.ref,
      title: form.subject || doc.ref,
      category: form.type,
      classification: 'Internal',
      version: 'V1.0',
      approval_status: 'Draft',
      created_by: profile?.id || null
    });
    setMessage(`Draft ${doc.ref} generated and registered. Route it through approvals before external issue.`);
  }

  return <div className="section">
    <h3>Document Generator</h3>
    <div className="form">
      <label>Type<select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option value="board_resolution">Board Resolution</option><option value="minutes_of_meeting">Minutes of Meeting</option><option value="quotation">Quotation</option><option value="invoice">Invoice</option><option value="purchase_order">Purchase Order</option><option value="discipline_notice">Discipline Notice</option><option value="compliance_report">Compliance Report</option></select></label>
      <label>Subject<input value={form.subject} onChange={e=>setForm({...form,subject:e.target.value})}/></label>
      <label>Signatory<input value={form.signatory} onChange={e=>setForm({...form,signatory:e.target.value})}/></label>
      <label className="full-field">Body<textarea rows="7" value={form.body} onChange={e=>setForm({...form,body:e.target.value})}/></label>
    </div>
    <button className="primary" onClick={createDraft}>Generate Draft + Register</button>
    {message && <p>{message}</p>}
  </div>;
}
