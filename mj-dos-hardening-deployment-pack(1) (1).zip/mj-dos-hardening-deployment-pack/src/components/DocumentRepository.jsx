import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../auth/AuthProvider';
import ModuleTable from './ModuleTable';

export default function DocumentRepository() {
  const { profile } = useAuth();
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState('');

  async function uploadFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true); setMessage('');
    const safeName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.\-_]/g,'_')}`;
    const path = `${profile?.id || 'unknown'}/${safeName}`;
    const { error: storageError } = await supabase.storage.from('mj-dos-documents').upload(path, file, { upsert: false });
    if (storageError) { setMessage(storageError.message); setUploading(false); return; }
    const { error } = await supabase.from('documents').insert({
      title: file.name, file_path: path, category: 'Other', classification: 'Internal', version: 'V1.0', approval_status: 'Draft', created_by: profile?.id || null
    });
    setMessage(error ? error.message : 'Document uploaded and registered.');
    setUploading(false);
  }

  return <div className="stack">
    <div className="section"><h3>Cloud Document Upload</h3><input type="file" onChange={uploadFile}/>{uploading && <p>Uploading...</p>}{message && <p>{message}</p>}</div>
    <ModuleTable table="documents" />
  </div>
}
