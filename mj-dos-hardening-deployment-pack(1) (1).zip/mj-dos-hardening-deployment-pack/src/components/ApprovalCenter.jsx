import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../auth/AuthProvider';
import ModuleTable from './ModuleTable';

export default function ApprovalCenter(){
  const { profile } = useAuth();
  const [pending, setPending] = useState([]);
  const [notes, setNotes] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => { loadPending(); }, [profile?.id]);

  async function loadPending(){
    if (!profile?.id) return;
    const { data } = await supabase.from('approvals').select('*').eq('archived', false).in('status', ['Submitted','Level 1 Approved','Level 2 Verified']);
    setPending(data || []);
  }

  async function decide(row, decision){
    setMessage('');
    const { error } = await supabase.rpc('process_approval_decision', { _approval_id: row.id, _decision: decision, _notes: notes });
    setMessage(error ? error.message : `Approval ${decision}.`);
    setNotes('');
    loadPending();
  }

  return <div className="stack">
    <div className="section notice"><b>Approval Gate:</b> Level 1 department approval, Level 2 finance/operations verification, Level 3 CEO/CFO/BoD approval. High-risk actions must route through this centre before execution.</div>
    <div className="section"><h3>Pending Workflow Actions</h3>{message && <p>{message}</p>}<textarea placeholder="Decision notes" value={notes} onChange={e=>setNotes(e.target.value)} rows="3" />
      <table><thead><tr><th>Ref</th><th>Title</th><th>Module</th><th>Level</th><th>Status</th><th>Action</th></tr></thead><tbody>{pending.map(row => <tr key={row.id}><td>{row.ref_no}</td><td>{row.request_title}</td><td>{row.module_name}</td><td>{row.level}</td><td>{row.status}</td><td><button className="primary" onClick={()=>decide(row,'approved')}>Approve</button> <button className="danger" onClick={()=>decide(row,'rejected')}>Reject</button></td></tr>)}</tbody></table>
    </div>
    <ModuleTable table="approvals" />
  </div>
}
