import { supabase } from '../lib/supabase';

export async function logAudit({ action_type, affected_table, affected_record_id = null, old_value = null, new_value = null }) {
  const { error } = await supabase.rpc('log_client_audit', {
    _action_type: action_type,
    _affected_table: affected_table,
    _affected_record_id: affected_record_id,
    _old_value: old_value,
    _new_value: new_value
  });
  if (error) console.warn('Audit RPC failed:', error.message);
}
