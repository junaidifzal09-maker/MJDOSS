export const roles = [
  'CEO Admin','BoD Viewer','CFO','COO','Compliance Officer','BD/Commercial','Accounts Officer','HR/Admin','Staff/User'
];

export const modules = {
  ceo: { label: 'CEO Dashboard', table: null, roles: ['CEO Admin','BoD Viewer'] },
  approvals: { label: 'Approval Centre', table: 'approvals', roles: ['CEO Admin','CFO','COO','Compliance Officer','HR/Admin'] },
  documents: { label: 'Documents', table: 'documents', roles: ['CEO Admin','CFO','COO','Compliance Officer','HR/Admin','Accounts Officer','BD/Commercial'] },
  docgen: { label: 'Document Generator', table: null, roles: ['CEO Admin','CFO','COO','Compliance Officer','HR/Admin','Accounts Officer'] },
  reports: { label: 'Reports', table: null, roles: ['CEO Admin','BoD Viewer','CFO','COO','Compliance Officer','HR/Admin'] },
  invoices: { label: 'Invoices', table: 'invoices', roles: ['CEO Admin','CFO','Accounts Officer'] },
  payments: { label: 'Receipts & Payments', table: 'receipts_payments', roles: ['CEO Admin','CFO','Accounts Officer'] },
  expenses: { label: 'Expenses', table: 'expenses', roles: ['CEO Admin','CFO','Accounts Officer'] },
  ledger: { label: 'Ledger Entries', table: 'ledger_entries', roles: ['CEO Admin','CFO','Accounts Officer'] },
  procurement: { label: 'Procurement Requests', table: 'procurement_requests', roles: ['CEO Admin','COO','CFO','Staff/User'] },
  purchase_orders: { label: 'Purchase Orders', table: 'purchase_orders', roles: ['CEO Admin','COO','CFO'] },
  inventory: { label: 'Inventory', table: 'inventory', roles: ['CEO Admin','COO'] },
  quality: { label: 'Quality Checks', table: 'quality_checks', roles: ['CEO Admin','COO','Compliance Officer'] },
  dispatch: { label: 'Dispatch', table: 'dispatch', roles: ['CEO Admin','COO','CFO'] },
  customers: { label: 'Customers', table: 'customers', roles: ['CEO Admin','BD/Commercial','CFO'] },
  quotations: { label: 'Quotations', table: 'quotations', roles: ['CEO Admin','BD/Commercial','CFO'] },
  sales_orders: { label: 'Sales Orders', table: 'sales_orders', roles: ['CEO Admin','BD/Commercial','CFO','COO'] },
  compliance: { label: 'Compliance Register', table: 'compliance', roles: ['CEO Admin','Compliance Officer','BoD Viewer'] },
  governance: { label: 'Governance Register', table: 'governance', roles: ['CEO Admin','Compliance Officer','BoD Viewer'] },
  employees: { label: 'Employees', table: 'employees', roles: ['CEO Admin','HR/Admin'] },
  attendance: { label: 'Attendance', table: 'attendance', roles: ['CEO Admin','HR/Admin','Staff/User'] },
  tasks: { label: 'Tasks', table: 'tasks', roles: ['CEO Admin','HR/Admin','Staff/User','COO'] },
  audit: { label: 'Audit Log', table: 'audit_log', roles: ['CEO Admin','BoD Viewer','Compliance Officer'] }
};

export const tableColumns = {
  approvals: ['ref_no','module_name','request_title','level','status','requested_by','approved_by','created_at'],
  documents: ['ref_no','title','category','classification','version','approval_status','expiry_date','created_at'],
  invoices: ['ref_no','customer_name','amount','status','due_date','created_at'],
  receipts_payments: ['ref_no','party_name','amount','payment_type','status','created_at'],
  expenses: ['ref_no','expense_type','amount','status','created_at'],
  ledger_entries: ['ref_no','account_name','debit','credit','status','created_at'],
  procurement_requests: ['ref_no','supplier_name','item_name','quantity','status','created_at'],
  purchase_orders: ['ref_no','supplier_name','amount','status','created_at'],
  inventory: ['sku','item_name','batch_no','qty_available','reserved_qty','status','created_at'],
  quality_checks: ['ref_no','sku','batch_no','result','status','created_at'],
  dispatch: ['ref_no','sales_order_ref','customer_name','dispatch_status','finance_clearance','quality_clearance','created_at'],
  customers: ['customer_name','country','contact_person','status','created_at'],
  quotations: ['ref_no','customer_name','amount','status','created_at'],
  sales_orders: ['ref_no','customer_name','amount','payment_status','approval_status','created_at'],
  compliance: ['ref_no','record_type','title','deadline','status','created_at'],
  governance: ['ref_no','record_type','title','approval_status','created_at'],
  employees: ['employee_code','full_name','department','role_name','status','created_at'],
  attendance: ['employee_id','attendance_date','check_in','check_out','status','created_at'],

  payroll_inputs: ['employee_id','month','gross_pay','deductions','net_pay','status','created_at'],
  bank_reconciliation: ['bank_name','statement_date','book_balance','bank_balance','status','created_at'],
  suppliers: ['supplier_name','country','contact_person','status','created_at'],
  leave_requests: ['employee_id','start_date','end_date','reason','status','created_at'],
  discipline_notices: ['employee_id','notice_type','violation','status','created_at'],
  appraisals: ['employee_id','period','rating','status','created_at'],
  tasks: ['title','assigned_to','due_date','status','created_at'],
  audit_log: ['created_at','action_type','affected_table','affected_record_id','ip_address']
};
