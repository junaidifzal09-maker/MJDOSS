import React, { useState } from 'react';
import { AuthProvider, useAuth } from './auth/AuthProvider';
import Layout from './components/Layout';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import ModuleTable from './components/ModuleTable';
import ApprovalCenter from './components/ApprovalCenter';
import DocumentRepository from './components/DocumentRepository';
import OfficeNetworkGate from './components/OfficeNetworkGate';
import ReportCenter from './components/ReportCenter';
import DocumentGenerator from './components/DocumentGenerator';
import { modules } from './data/modules';
import './styles.css';

function AppBody(){
  const { session, profile, loading } = useAuth();
  const [current, setCurrent] = useState('ceo');
  if (loading) return <div className="loading">Loading MJ-DOS...</div>;
  if (!session) return <Login />;
  if (!profile) return <div className="login-shell"><div className="login-card"><h1>Access Pending</h1><p>Your Google login succeeded, but your email has not been approved in MJ-DOS users table. Ask CEO/Admin to activate your profile.</p></div></div>;
  const mod = modules[current];
  return <OfficeNetworkGate><Layout current={current} setCurrent={setCurrent}>{current==='ceo' && <Dashboard />}{current==='approvals' && <ApprovalCenter />}{current==='documents' && <DocumentRepository />}
      {current==='docgen' && <DocumentGenerator />}
      {current==='reports' && <ReportCenter />}{mod?.table && !['approvals','documents'].includes(current) && <ModuleTable table={mod.table} />}</Layout></OfficeNetworkGate>;
}

export default function App(){return <AuthProvider><AppBody /></AuthProvider>}
