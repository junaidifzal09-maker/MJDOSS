import fs from 'node:fs';
import process from 'node:process';
import { createClient } from '@supabase/supabase-js';

const [, , inputPath] = process.argv;
if (!inputPath) {
  console.error('Usage: node scripts/migrate_localstorage_to_supabase.mjs localstorage-export.json');
  process.exit(1);
}

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error('Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in the shell. Never expose service_role in frontend code.');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
const raw = JSON.parse(fs.readFileSync(inputPath, 'utf8'));

const tableMap = {
  invoices: 'invoices',
  receipts_payments: 'receipts_payments',
  expenses: 'expenses',
  ledger_entries: 'ledger_entries',
  suppliers: 'suppliers',
  procurement_requests: 'procurement_requests',
  purchase_orders: 'purchase_orders',
  inventory: 'inventory',
  quality_checks: 'quality_checks',
  dispatch: 'dispatch',
  customers: 'customers',
  quotations: 'quotations',
  sales_orders: 'sales_orders',
  compliance: 'compliance',
  governance: 'governance',
  employees: 'employees',
  attendance: 'attendance',
  tasks: 'tasks',
  documents: 'documents'
};

function normaliseRecord(record) {
  const clean = { ...record };
  delete clean.id; // let production database issue UUIDs unless IDs were already UUID-safe and mapped deliberately
  clean.archived = Boolean(clean.archived || clean.is_archived || false);
  return clean;
}

for (const [sourceKey, table] of Object.entries(tableMap)) {
  const rows = Array.isArray(raw[sourceKey]) ? raw[sourceKey] : [];
  if (!rows.length) continue;
  const payload = rows.map(normaliseRecord);
  const { error } = await supabase.from(table).insert(payload);
  if (error) {
    console.error(`Failed ${sourceKey} -> ${table}:`, error.message);
  } else {
    console.log(`Migrated ${payload.length} rows into ${table}`);
  }
}

console.log('Migration pass completed. Reconcile row counts before production cutover.');
