-- MJ-DOS ERP — UAT Smoke Test Queries
-- Run after migrations and demo/test users are created.

-- 1. Tables present
select count(*) as public_table_count
from information_schema.tables
where table_schema='public';

-- 2. Functions present
select routine_name
from information_schema.routines
where routine_schema='public'
order by routine_name;

-- 3. RLS status
select tablename, rowsecurity
from pg_tables
where schemaname='public'
order by tablename;

-- 4. Roles seeded
select name from roles order by name;

-- 5. Authority matrix check
select r.name as role, module, action
from authority_matrix am
join roles r on r.id = am.role_id
order by r.name, module, action;

-- 6. Audit immutability test: should fail if uncommented
-- update audit_log set action_type='tamper-test';
-- delete from audit_log;

-- 7. Dispatch readiness test placeholder
-- select check_dispatch_readiness('<dispatch-id>'::uuid);
