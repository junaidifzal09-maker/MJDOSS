#!/usr/bin/env bash
set -euo pipefail

printf '\nMJ-DOS ERP deployment preflight\n'
node --version
npm --version
npm install
npm run build
printf '\nBuild completed. Now run Supabase migrations and UAT checklist.\n'
