-- MJ-DOS ERP Supabase Verification Script

-- 1. Expected tables
select table_name
from information_schema.tables
where table_schema = 'public'
order by table_name;

-- 2. Expected functions
select routine_name
from information_schema.routines
where routine_schema = 'public'
  and routine_type = 'FUNCTION'
order by routine_name;

-- 3. RLS disabled check: should return zero rows except explicitly exempt system tables.
select tablename, rowsecurity
from pg_tables
where schemaname = 'public'
  and rowsecurity = false
order by tablename;

-- 4. Role seed check
select role_name, description from roles order by role_name;

-- 5. Authority matrix coverage
select role_name, count(*) as module_permissions
from authority_matrix
group by role_name
order by role_name;

-- 6. Audit immutability trigger check
select tgname, tgrelid::regclass as table_name
from pg_trigger
where tgname = 'trg_no_audit_update';

-- 7. Storage bucket check
select id, name, public
from storage.buckets
where id = 'mj-dos-documents';

-- 8. Dispatch readiness smoke check: run manually after creating a dispatch record.
-- select public.check_dispatch_readiness('<dispatch-id>'::uuid);
