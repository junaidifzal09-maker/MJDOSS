# MJ-DOS ERP — Hardening & Deployment Pack

This package is the hardening and deployment pack for MJ-DOS ERP. It combines the production starter with deployment validation, RLS/audit/approval controls, UAT material, migration utilities, and role-based training support.

## Stack

- Frontend: React + Vite
- Auth: Supabase Auth with Google OAuth
- Database: Supabase PostgreSQL
- Security: Supabase Row Level Security
- Storage: Supabase Storage bucket named `documents`
- Backend logic: Supabase Edge Functions
- Deployment: Netlify or Vercel

## What is included

```txt
src/                       React app
supabase/migrations/       PostgreSQL schema, RLS, audit, storage, seed authority
supabase/functions/        Edge functions for audit, dispatch clearance, document generation
netlify.toml               Netlify deployment and SPA routing
vercel.json                Vercel deployment and SPA routing
.env.example               Required environment variables
```

## First-time setup

1. Create a Supabase project.
2. Enable Google provider in Supabase Auth.
3. Apply migrations in order:
   - `001_schema.sql`
   - `002_rls_audit.sql`
   - `003_storage.sql`
   - `004_seed_authority.sql`
4. Copy `.env.example` to `.env.local` and fill values.
5. Install dependencies and run:

```bash
npm install
npm run dev
```

6. First Google login creates an inactive `users` profile.
7. In Supabase SQL editor, activate the first CEO Admin manually:

```sql
update public.users
set is_active = true, role_name = 'CEO Admin', ip_exempt = true
where email = 'YOUR_EMAIL@DOMAIN.COM';
```

## Production guardrails already added

- No hard delete pattern through `archived` fields.
- Immutable `audit_log` trigger blocks update/delete.
- Dispatch status is forced to `Blocked` unless all clearance flags are true.
- Google-authenticated users must be approved in `public.users`.
- Finance tables are restricted to CEO/CFO/Accounts roles.
- Ledger writes are blocked for commercial users through RLS.
- Documents are stored in private Supabase Storage.

## Before go-live

- Run all Supabase migrations in order.
- Configure Google OAuth and the private document bucket.
- Run `npm run build` and `npm run preflight`.
- Complete the UAT matrix and security acceptance tests.
- Assign the first CEO Admin user manually after first login.
- Retire the LocalStorage MVP only after data migration verification.

