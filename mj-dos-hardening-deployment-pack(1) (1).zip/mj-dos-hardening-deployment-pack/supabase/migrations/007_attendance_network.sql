-- MJ-DOS ERP hardening migration: attendance guardrails.

alter table attendance add column if not exists ip_address text;
alter table attendance add column if not exists user_agent text;
alter table attendance add column if not exists daily_report text;

create or replace function public.mark_attendance(_daily_report text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare employee uuid := public.current_app_user_id(); rid uuid;
begin
  if employee is null then raise exception 'Inactive or unauthorized user'; end if;
  insert into attendance(employee_id, attendance_date, check_in, status, daily_report, created_by)
  values(employee, current_date, now(), case when now()::time > time '11:20' then 'Late' else 'Present' end, _daily_report, employee)
  returning id into rid;
  return rid;
end; $$;

grant execute on function public.mark_attendance(text) to authenticated;
