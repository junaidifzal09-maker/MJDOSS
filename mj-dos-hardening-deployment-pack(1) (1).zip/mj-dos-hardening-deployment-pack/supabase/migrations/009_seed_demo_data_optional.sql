-- OPTIONAL: demo data for UAT. Do not run in live production unless explicitly approved.
insert into customers(customer_name,country,contact_person,status) values ('Sample EU Distributor','France','UAT Contact','Active') on conflict do nothing;
insert into inventory(sku,item_name,batch_no,qty_available,reserved_qty,status) values ('TAV-BIR-100','TAVAAZO Biryani Masala 100g','UAT-BATCH-001',1000,0,'Available') on conflict do nothing;
insert into compliance(ref_no,record_type,title,deadline,status) values ('MJAGRO-COMP-UAT-001','SECP','Annual return test record',current_date + interval '20 days','Open') on conflict do nothing;
