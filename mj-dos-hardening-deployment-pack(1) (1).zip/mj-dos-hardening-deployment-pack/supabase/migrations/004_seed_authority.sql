-- Starter authority matrix. Adjust in admin panel after first CEO Admin profile is activated.
insert into authority_matrix(role_name,module_name,can_view,can_create,can_update,can_approve_l1,can_approve_l2,can_approve_l3,can_archive,can_view_pnl)
select r.role_name, m.module_name,
  case when r.role_name='CEO Admin' then true when r.role_name='BoD Viewer' and m.module_name in ('governance','compliance','audit_log','reports') then true else true end,
  case when r.role_name in ('CEO Admin','CFO','COO','Compliance Officer','BD/Commercial','Accounts Officer','HR/Admin','Staff/User') then true else false end,
  case when r.role_name <> 'BoD Viewer' then true else false end,
  case when r.role_name in ('CEO Admin','CFO','COO','Compliance Officer','HR/Admin') then true else false end,
  case when r.role_name in ('CEO Admin','CFO','COO') then true else false end,
  case when r.role_name in ('CEO Admin','CFO') then true else false end,
  case when r.role_name in ('CEO Admin','CFO','COO','Compliance Officer') then true else false end,
  case when r.role_name in ('CEO Admin','BoD Viewer','CFO') then true else false end
from roles r
cross join (values
('approvals'),('documents'),('invoices'),('receipts_payments'),('expenses'),('ledger_entries'),('payroll_inputs'),('bank_reconciliation'),('suppliers'),('procurement_requests'),('purchase_orders'),('inventory'),('quality_checks'),('dispatch'),('customers'),('quotations'),('sales_orders'),('distributors'),('marketing_campaigns'),('compliance'),('governance'),('employees'),('attendance'),('leave_requests'),('discipline_notices'),('appraisals'),('tasks'),('audit_log'),('reports')
) as m(module_name)
on conflict(role_name,module_name) do nothing;
