-- MJ-DOS ERP hardening migration: workflow, notifications, office network and client audit RPC.

create table if not exists notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references users(id) on delete cascade,
  type text not null default 'system',
  title text not null,
  message text,
  link text,
  is_read boolean default false,
  created_at timestamptz default now()
);

create table if not exists office_networks (
  id uuid primary key default uuid_generate_v4(),
  label text not null,
  public_ip text not null unique,
  is_active boolean default true,
  created_by uuid references users(id),
  created_at timestamptz default now()
);

create table if not exists document_versions (
  id uuid primary key default uuid_generate_v4(),
  document_id uuid references documents(id) on delete cascade,
  version text not null,
  file_path text,
  uploaded_by uuid references users(id),
  created_at timestamptz default now()
);

alter table notifications enable row level security;
alter table office_networks enable row level security;
alter table document_versions enable row level security;

create policy "notifications own read" on notifications for select using (user_id = public.current_app_user_id() or public.current_app_role() = 'CEO Admin');
create policy "notifications own update" on notifications for update using (user_id = public.current_app_user_id()) with check (user_id = public.current_app_user_id());
create policy "notifications system insert" on notifications for insert with check (public.current_app_user_id() is not null);

create policy "office networks admin read" on office_networks for select using (public.current_app_role() = 'CEO Admin');
create policy "office networks admin manage" on office_networks for all using (public.current_app_role() = 'CEO Admin') with check (public.current_app_role() = 'CEO Admin');

create policy "document versions read" on document_versions for select using (public.current_app_user_id() is not null);
create policy "document versions insert" on document_versions for insert with check (public.current_app_user_id() is not null);

create or replace function public.log_client_audit(
  _action_type text,
  _affected_table text,
  _affected_record_id uuid default null,
  _old_value jsonb default null,
  _new_value jsonb default null
)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.audit_log(user_id, role_name, action_type, affected_table, affected_record_id, old_value, new_value)
  values(public.current_app_user_id(), public.current_app_role(), _action_type, _affected_table, _affected_record_id, _old_value, _new_value);
end; $$;

grant execute on function public.log_client_audit(text,text,uuid,jsonb,jsonb) to authenticated;

create or replace function public.process_approval_decision(_approval_id uuid, _decision text, _notes text default null)
returns void language plpgsql security definer set search_path = public as $$
declare
  a approvals%rowtype;
  actor uuid := public.current_app_user_id();
  actor_role text := public.current_app_role();
  next_status text;
begin
  if actor is null then raise exception 'Inactive or unauthorized user'; end if;
  if _decision not in ('approved','rejected') then raise exception 'Decision must be approved or rejected'; end if;

  select * into a from approvals where id = _approval_id and archived = false for update;
  if not found then raise exception 'Approval not found'; end if;

  if _decision = 'rejected' then
    update approvals set status='Rejected', approved_by=actor, approval_notes=_notes, updated_at=now() where id=_approval_id;
    insert into approval_history(approval_id, action, level, actor_id, notes) values(_approval_id, 'Rejected', a.level, actor, _notes);
  else
    if a.level = 1 then
      next_status := 'Level 1 Approved';
      update approvals set status=next_status, level=2, approved_by=actor, approval_notes=_notes, updated_at=now() where id=_approval_id;
    elsif a.level = 2 then
      next_status := 'Level 2 Verified';
      update approvals set status=next_status, level=3, approved_by=actor, approval_notes=_notes, updated_at=now() where id=_approval_id;
    else
      next_status := 'Approved';
      update approvals set status=next_status, approved_by=actor, approval_notes=_notes, updated_at=now() where id=_approval_id;
    end if;
    insert into approval_history(approval_id, action, level, actor_id, notes) values(_approval_id, next_status, a.level, actor, _notes);
  end if;

  insert into notifications(user_id, type, title, message, link)
  values(coalesce(a.requested_by, a.created_by), 'approval_update', 'Approval updated', a.request_title || ' is now ' || coalesce(next_status,'Rejected'), '/approvals');
end; $$;

grant execute on function public.process_approval_decision(uuid,text,text) to authenticated;
