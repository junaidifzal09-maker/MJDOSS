-- MJ-DOS ERP hardening migration: executive report RPCs.

create or replace function public.get_ceo_report()
returns jsonb language plpgsql security definer set search_path = public as $$
declare r jsonb;
begin
  if public.current_app_role() not in ('CEO Admin','BoD Viewer','CFO','COO') then raise exception 'Not authorized for CEO report'; end if;
  select jsonb_build_object(
    'pending_approvals', (select count(*) from approvals where archived=false and status not in ('Approved','Rejected','Archived')),
    'invoice_value', coalesce((select sum(amount) from invoices where archived=false),0),
    'sales_order_value', coalesce((select sum(amount) from sales_orders where archived=false),0),
    'blocked_dispatches', (select count(*) from dispatch where archived=false and dispatch_status='Blocked'),
    'compliance_deadlines', (select count(*) from compliance where archived=false and deadline between current_date and current_date + interval '30 days'),
    'attendance_records', (select count(*) from attendance where archived=false and attendance_date=current_date),
    'open_tasks', (select count(*) from tasks where archived=false and status not in ('Done','Closed','Archived'))
  ) into r;
  return r;
end; $$;

create or replace function public.get_cfo_report()
returns jsonb language plpgsql security definer set search_path = public as $$
declare r jsonb;
begin
  if public.current_app_role() not in ('CEO Admin','CFO','Accounts Officer','BoD Viewer') then raise exception 'Not authorized for CFO report'; end if;
  select jsonb_build_object(
    'invoice_value', coalesce((select sum(amount) from invoices where archived=false),0),
    'receipts_payments_value', coalesce((select sum(amount) from receipts_payments where archived=false),0),
    'expense_value', coalesce((select sum(amount) from expenses where archived=false),0),
    'ledger_debits', coalesce((select sum(debit) from ledger_entries where archived=false),0),
    'ledger_credits', coalesce((select sum(credit) from ledger_entries where archived=false),0),
    'pending_finance_approvals', (select count(*) from approvals where archived=false and module_name in ('finance','invoices','expenses','ledger_entries') and status not in ('Approved','Rejected','Archived'))
  ) into r;
  return r;
end; $$;

grant execute on function public.get_ceo_report() to authenticated;
grant execute on function public.get_cfo_report() to authenticated;
