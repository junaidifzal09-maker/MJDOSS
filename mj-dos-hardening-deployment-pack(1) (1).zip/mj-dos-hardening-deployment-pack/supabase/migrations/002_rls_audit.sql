-- MJ-DOS RLS + Audit + Dispatch Guards

create or replace function public.current_app_user_id()
returns uuid language sql stable security definer set search_path = public as $$
  select id from public.users where auth_user_id = auth.uid() and is_active = true limit 1;
$$;

create or replace function public.current_app_role()
returns text language sql stable security definer set search_path = public as $$
  select role_name from public.users where auth_user_id = auth.uid() and is_active = true limit 1;
$$;

create or replace function public.role_can(module text, permission text)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare r text := public.current_app_role(); allowed boolean := false;
begin
  if r = 'CEO Admin' then return true; end if;
  execute format('select coalesce(%I,false) from public.authority_matrix where role_name=$1 and module_name=$2', permission)
  into allowed using r, module;
  return coalesce(allowed,false);
end; $$;

create or replace function public.prevent_audit_mutation()
returns trigger language plpgsql as $$
begin
  raise exception 'audit_log is immutable';
end; $$;

drop trigger if exists trg_no_audit_update on audit_log;
create trigger trg_no_audit_update before update or delete on audit_log for each row execute function prevent_audit_mutation();

create or replace function public.write_audit()
returns trigger language plpgsql security definer set search_path = public as $$
declare app_user uuid; app_role text;
begin
  app_user := public.current_app_user_id();
  app_role := public.current_app_role();
  insert into public.audit_log(user_id, role_name, action_type, affected_table, affected_record_id, old_value, new_value)
  values(app_user, app_role, TG_OP, TG_TABLE_NAME, coalesce(new.id, old.id), to_jsonb(old), to_jsonb(new));
  return coalesce(new, old);
end; $$;

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

create or replace function public.enforce_dispatch_clearance()
returns trigger language plpgsql as $$
begin
  if new.finance_clearance and new.quality_clearance and new.document_clearance and new.inventory_reserved and new.coo_approval then
    if new.dispatch_status = 'Blocked' then new.dispatch_status := 'Cleared'; end if;
  else
    new.dispatch_status := 'Blocked';
  end if;
  return new;
end; $$;

create or replace function public.handle_new_auth_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.users(auth_user_id,email,full_name,is_active,role_name)
  values(new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', new.email), false, 'Staff/User')
  on conflict(auth_user_id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_auth_user();

-- Enable RLS on all application tables.
do $$
declare t text;
begin
  foreach t in array array['users','roles','authority_matrix','approvals','approval_history','documents','audit_log','invoices','receipts_payments','expenses','ledger_entries','payroll_inputs','bank_reconciliation','suppliers','procurement_requests','purchase_orders','inventory','quality_checks','dispatch','customers','quotations','sales_orders','distributors','marketing_campaigns','compliance','governance','employees','attendance','leave_requests','discipline_notices','appraisals','tasks'] loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;

-- Generic read policy: active users can read rows allowed by authority matrix. CEO can read all.
create policy "users read own or admin" on users for select using (auth_user_id = auth.uid() or public.current_app_role() in ('CEO Admin','HR/Admin'));
create policy "users admin update" on users for update using (public.current_app_role() = 'CEO Admin') with check (public.current_app_role() = 'CEO Admin');
create policy "roles read authenticated" on roles for select to authenticated using (true);
create policy "authority read active" on authority_matrix for select to authenticated using (public.current_app_user_id() is not null);
create policy "authority admin manage" on authority_matrix for all using (public.current_app_role()='CEO Admin') with check (public.current_app_role()='CEO Admin');

-- Audit read only for governance roles.
create policy "audit governance read" on audit_log for select using (public.current_app_role() in ('CEO Admin','BoD Viewer','Compliance Officer'));

-- Finance RLS
create policy "finance invoices read" on invoices for select using (public.current_app_role() in ('CEO Admin','CFO','Accounts Officer','BoD Viewer'));
create policy "finance invoices write" on invoices for insert with check (public.current_app_role() in ('CEO Admin','CFO','Accounts Officer'));
create policy "finance invoices update" on invoices for update using (public.current_app_role() in ('CEO Admin','CFO','Accounts Officer'));
create policy "payments read" on receipts_payments for select using (public.current_app_role() in ('CEO Admin','CFO','Accounts Officer','BoD Viewer'));
create policy "payments write" on receipts_payments for insert with check (public.current_app_role() in ('CEO Admin','CFO','Accounts Officer'));
create policy "payments update" on receipts_payments for update using (public.current_app_role() in ('CEO Admin','CFO','Accounts Officer'));
create policy "expenses read" on expenses for select using (public.current_app_role() in ('CEO Admin','CFO','Accounts Officer','BoD Viewer'));
create policy "expenses write" on expenses for insert with check (public.current_app_role() in ('CEO Admin','CFO','Accounts Officer'));
create policy "expenses update" on expenses for update using (public.current_app_role() in ('CEO Admin','CFO','Accounts Officer'));
create policy "ledger read restricted" on ledger_entries for select using (public.current_app_role() in ('CEO Admin','CFO','Accounts Officer','BoD Viewer'));
create policy "ledger write restricted" on ledger_entries for insert with check (public.current_app_role() in ('CEO Admin','CFO','Accounts Officer'));
create policy "ledger update restricted" on ledger_entries for update using (public.current_app_role() in ('CEO Admin','CFO'));

-- Operations/commercial/hr broad policies.
do $$
declare t text;
begin
  foreach t in array array['approvals','approval_history','documents','payroll_inputs','bank_reconciliation','suppliers','procurement_requests','purchase_orders','inventory','quality_checks','dispatch','customers','quotations','sales_orders','distributors','marketing_campaigns','compliance','governance','employees','attendance','leave_requests','discipline_notices','appraisals','tasks'] loop
    execute format('create policy %I on public.%I for select using (public.current_app_user_id() is not null)', 'read_'||t, t);
    execute format('create policy %I on public.%I for insert with check (public.current_app_user_id() is not null)', 'insert_'||t, t);
    execute format('create policy %I on public.%I for update using (public.current_app_user_id() is not null)', 'update_'||t, t);
  end loop;
end $$;

-- Attach audit/update triggers to business tables.
do $$
declare t text;
begin
  foreach t in array array['users','authority_matrix','approvals','approval_history','documents','invoices','receipts_payments','expenses','ledger_entries','payroll_inputs','bank_reconciliation','suppliers','procurement_requests','purchase_orders','inventory','quality_checks','dispatch','customers','quotations','sales_orders','distributors','marketing_campaigns','compliance','governance','employees','attendance','leave_requests','discipline_notices','appraisals','tasks'] loop
    execute format('drop trigger if exists audit_%I on public.%I', t, t);
    execute format('create trigger audit_%I after insert or update or delete on public.%I for each row execute function public.write_audit()', t, t);
    execute format('drop trigger if exists touch_%I on public.%I', t, t);
    begin
      execute format('create trigger touch_%I before update on public.%I for each row execute function public.touch_updated_at()', t, t);
    exception when undefined_column then null;
    end;
  end loop;
end $$;

drop trigger if exists dispatch_guard on dispatch;
create trigger dispatch_guard before insert or update on dispatch for each row execute function public.enforce_dispatch_clearance();
