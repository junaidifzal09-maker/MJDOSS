-- Supabase Storage bucket and policies
insert into storage.buckets (id, name, public)
values ('mj-dos-documents','mj-dos-documents',false)
on conflict(id) do nothing;

create policy "document storage read" on storage.objects for select using (
  bucket_id = 'mj-dos-documents' and public.current_app_user_id() is not null
);

create policy "document storage upload" on storage.objects for insert with check (
  bucket_id = 'mj-dos-documents' and public.current_app_user_id() is not null
);

create policy "document storage update admin" on storage.objects for update using (
  bucket_id = 'mj-dos-documents' and public.current_app_role() in ('CEO Admin','Compliance Officer')
);
