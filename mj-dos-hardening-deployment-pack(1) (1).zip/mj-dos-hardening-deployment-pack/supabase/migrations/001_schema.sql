-- MJ-DOS ERP Production Schema
create extension if not exists "uuid-ossp";

create table if not exists roles (
  id uuid primary key default uuid_generate_v4(),
  role_name text unique not null,
  description text,
  created_at timestamptz default now()
);

insert into roles(role_name, description) values
('CEO Admin','Full system access'),('BoD Viewer','Governance and reports view'),('CFO','Finance and approvals'),('COO','Operations and dispatch'),('Compliance Officer','Compliance and governance'),('BD/Commercial','Customers, quotations and sales pipeline'),('Accounts Officer','Finance data entry'),('HR/Admin','HR, attendance and admin'),('Staff/User','Own tasks, attendance and reports')
on conflict(role_name) do nothing;

create table if not exists users (
  id uuid primary key default uuid_generate_v4(),
  auth_user_id uuid unique references auth.users(id) on delete cascade,
  email text unique not null,
  full_name text,
  role_name text references roles(role_name) default 'Staff/User',
  department text,
  is_active boolean default false,
  ip_exempt boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists authority_matrix (
  id uuid primary key default uuid_generate_v4(),
  role_name text references roles(role_name),
  module_name text not null,
  can_view boolean default false,
  can_create boolean default false,
  can_update boolean default false,
  can_approve_l1 boolean default false,
  can_approve_l2 boolean default false,
  can_approve_l3 boolean default false,
  can_archive boolean default false,
  can_view_pnl boolean default false,
  created_at timestamptz default now(),
  unique(role_name, module_name)
);

create table if not exists approvals (
  id uuid primary key default uuid_generate_v4(),
  ref_no text unique default ('MJAGRO-APP-' || to_char(now(),'YYYYMMDD') || '-' || upper(substr(md5(random()::text),1,6))),
  module_name text not null,
  affected_table text,
  affected_record_id uuid,
  request_title text not null,
  level int check(level between 1 and 3) default 1,
  status text check(status in ('Draft','Submitted','Level 1 Approved','Level 2 Verified','Approved','Rejected','Archived')) default 'Draft',
  requested_by uuid references users(id),
  approved_by uuid references users(id),
  approval_notes text,
  archived boolean default false,
  created_by uuid references users(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists approval_history (
  id uuid primary key default uuid_generate_v4(),
  approval_id uuid references approvals(id) on delete cascade,
  action text not null,
  level int,
  actor_id uuid references users(id),
  notes text,
  created_at timestamptz default now()
);

create table if not exists documents (
  id uuid primary key default uuid_generate_v4(),
  ref_no text unique default ('MJAGRO-DOC-' || to_char(now(),'YYYYMMDD') || '-' || upper(substr(md5(random()::text),1,6))),
  title text not null,
  category text default 'Other',
  classification text check(classification in ('Public','Internal','Confidential','Restricted')) default 'Internal',
  version text default 'V1.0',
  approval_status text default 'Draft',
  file_path text,
  linked_table text,
  linked_record_id uuid,
  expiry_date date,
  archived boolean default false,
  created_by uuid references users(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists audit_log (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references users(id),
  role_name text,
  action_type text not null,
  affected_table text not null,
  affected_record_id uuid,
  old_value jsonb,
  new_value jsonb,
  ip_address text,
  user_agent text,
  created_at timestamptz default now()
);

-- Generic operational/finance/commercial tables
create table if not exists invoices (id uuid primary key default uuid_generate_v4(), ref_no text unique default ('MJAGRO-INV-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(md5(random()::text),1,6))), customer_name text, amount numeric default 0, status text default 'Draft', due_date date, archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists receipts_payments (id uuid primary key default uuid_generate_v4(), ref_no text unique default ('MJAGRO-RP-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(md5(random()::text),1,6))), party_name text, amount numeric default 0, payment_type text, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists expenses (id uuid primary key default uuid_generate_v4(), ref_no text unique default ('MJAGRO-EXP-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(md5(random()::text),1,6))), expense_type text, amount numeric default 0, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists ledger_entries (id uuid primary key default uuid_generate_v4(), ref_no text unique default ('MJAGRO-LED-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(md5(random()::text),1,6))), account_name text, debit numeric default 0, credit numeric default 0, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists payroll_inputs (id uuid primary key default uuid_generate_v4(), employee_id uuid, month text, gross_pay numeric default 0, deductions numeric default 0, net_pay numeric default 0, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists bank_reconciliation (id uuid primary key default uuid_generate_v4(), bank_name text, statement_date date, book_balance numeric default 0, bank_balance numeric default 0, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists suppliers (id uuid primary key default uuid_generate_v4(), supplier_name text, country text, contact_person text, status text default 'Active', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists procurement_requests (id uuid primary key default uuid_generate_v4(), ref_no text unique default ('MJAGRO-PR-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(md5(random()::text),1,6))), supplier_name text, item_name text, quantity numeric default 0, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists purchase_orders (id uuid primary key default uuid_generate_v4(), ref_no text unique default ('MJAGRO-PO-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(md5(random()::text),1,6))), supplier_name text, amount numeric default 0, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists inventory (id uuid primary key default uuid_generate_v4(), sku text, item_name text, batch_no text, qty_available numeric default 0, reserved_qty numeric default 0, status text default 'Available', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists quality_checks (id uuid primary key default uuid_generate_v4(), ref_no text unique default ('MJAGRO-QC-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(md5(random()::text),1,6))), sku text, batch_no text, result text, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists dispatch (id uuid primary key default uuid_generate_v4(), ref_no text unique default ('MJAGRO-DIS-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(md5(random()::text),1,6))), sales_order_ref text, customer_name text, dispatch_status text default 'Blocked', finance_clearance boolean default false, quality_clearance boolean default false, document_clearance boolean default false, inventory_reserved boolean default false, coo_approval boolean default false, archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists customers (id uuid primary key default uuid_generate_v4(), customer_name text, country text, contact_person text, status text default 'Active', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists quotations (id uuid primary key default uuid_generate_v4(), ref_no text unique default ('MJAGRO-QTN-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(md5(random()::text),1,6))), customer_name text, amount numeric default 0, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists sales_orders (id uuid primary key default uuid_generate_v4(), ref_no text unique default ('MJAGRO-SO-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(md5(random()::text),1,6))), customer_name text, amount numeric default 0, payment_status text default 'Pending', approval_status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists distributors (id uuid primary key default uuid_generate_v4(), distributor_name text, country text, territory text, agreement_status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists marketing_campaigns (id uuid primary key default uuid_generate_v4(), campaign_name text, market text, budget numeric default 0, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists compliance (id uuid primary key default uuid_generate_v4(), ref_no text unique default ('MJAGRO-COMP-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(md5(random()::text),1,6))), record_type text, title text, deadline date, status text default 'Open', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists governance (id uuid primary key default uuid_generate_v4(), ref_no text unique default ('MJAGRO-GOV-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(md5(random()::text),1,6))), record_type text, title text, approval_status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists employees (id uuid primary key default uuid_generate_v4(), employee_code text, full_name text, department text, role_name text, status text default 'Active', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists attendance (id uuid primary key default uuid_generate_v4(), employee_id uuid, attendance_date date default current_date, check_in timestamptz, check_out timestamptz, status text default 'Present', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists leave_requests (id uuid primary key default uuid_generate_v4(), employee_id uuid, start_date date, end_date date, reason text, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists discipline_notices (id uuid primary key default uuid_generate_v4(), employee_id uuid, notice_type text, violation text, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists appraisals (id uuid primary key default uuid_generate_v4(), employee_id uuid, period text, rating text, status text default 'Draft', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table if not exists tasks (id uuid primary key default uuid_generate_v4(), title text, assigned_to uuid, due_date date, status text default 'Open', archived boolean default false, created_by uuid references users(id), created_at timestamptz default now(), updated_at timestamptz default now());
