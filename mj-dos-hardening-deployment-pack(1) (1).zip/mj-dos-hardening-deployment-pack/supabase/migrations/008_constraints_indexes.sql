-- MJ-DOS ERP hardening migration: performance indexes and constraints.

create index if not exists idx_audit_log_created_at on audit_log(created_at desc);
create index if not exists idx_approvals_status on approvals(status);
create index if not exists idx_documents_category on documents(category);
create index if not exists idx_dispatch_status on dispatch(dispatch_status);
create index if not exists idx_tasks_due_date on tasks(due_date);
create index if not exists idx_attendance_date on attendance(attendance_date);

alter table ledger_entries add constraint ledger_non_negative_debit check (debit >= 0) not valid;
alter table ledger_entries add constraint ledger_non_negative_credit check (credit >= 0) not valid;
alter table invoices add constraint invoice_non_negative_amount check (amount >= 0) not valid;
alter table expenses add constraint expense_non_negative_amount check (amount >= 0) not valid;
