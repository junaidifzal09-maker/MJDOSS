import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'

serve(async (req) => {
  const body = await req.json()
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${body.title || 'MJ-DOS Document'}</title><style>body{font-family:Arial;padding:32px;color:#1f2937}h1{color:#123d2a}table{width:100%;border-collapse:collapse}td,th{border:1px solid #ddd;padding:8px}</style></head><body><h1>${body.doc_type || 'Controlled Document'}</h1><p><b>Reference:</b> ${body.ref_no || ''}</p><p><b>Status:</b> ${body.status || 'Draft'}</p><hr/><div>${String(body.body || '').replace(/\n/g,'<br/>')}</div><hr/><p>For and on behalf of MJ Agro Trading (Pvt) Ltd</p><p>Name: ____________________ Signature: ____________________ Date: ____________________</p></body></html>`
  return new Response(html, { headers: { 'Content-Type': 'text/html' } })
})
