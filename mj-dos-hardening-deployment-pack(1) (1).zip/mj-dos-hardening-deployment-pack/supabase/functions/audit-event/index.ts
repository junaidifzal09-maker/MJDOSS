import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

serve(async (req) => {
  const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
  const body = await req.json()
  const authHeader = req.headers.get('Authorization') || ''
  const token = authHeader.replace('Bearer ', '')
  const { data: { user } } = await supabase.auth.getUser(token)
  if (!user) return new Response('Unauthorized', { status: 401 })
  const { data: appUser } = await supabase.from('users').select('id,role_name').eq('auth_user_id', user.id).single()
  const ip = req.headers.get('x-forwarded-for') || req.headers.get('cf-connecting-ip') || ''
  const ua = req.headers.get('user-agent') || ''
  const { error } = await supabase.from('audit_log').insert({
    user_id: appUser?.id, role_name: appUser?.role_name, action_type: body.action_type,
    affected_table: body.affected_table, affected_record_id: body.affected_record_id,
    old_value: body.old_value || null, new_value: body.new_value || null, ip_address: ip, user_agent: ua
  })
  return new Response(JSON.stringify({ ok: !error, error: error?.message }), { headers: { 'Content-Type': 'application/json' }, status: error ? 400 : 200 })
})
