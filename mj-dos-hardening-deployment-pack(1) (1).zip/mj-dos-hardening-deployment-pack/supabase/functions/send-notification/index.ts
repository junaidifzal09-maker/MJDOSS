import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

serve(async (req) => {
  const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const { user_id, type = 'system', title, message, link = null } = await req.json();
  if (!user_id || !title) return new Response(JSON.stringify({ ok: false, error: 'user_id and title are required' }), { status: 400 });
  const { error } = await supabase.from('notifications').insert({ user_id, type, title, message, link });
  return new Response(JSON.stringify({ ok: !error, error: error?.message }), { headers: { 'Content-Type': 'application/json' }, status: error ? 500 : 200 });
});
