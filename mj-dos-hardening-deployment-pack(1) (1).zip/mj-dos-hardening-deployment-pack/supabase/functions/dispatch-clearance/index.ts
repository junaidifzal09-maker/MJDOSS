import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

serve(async (req) => {
  const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
  const { dispatch_id } = await req.json()
  const { data, error } = await supabase.from('dispatch').select('*').eq('id', dispatch_id).single()
  if (error) return new Response(error.message, { status: 400 })
  const cleared = data.finance_clearance && data.quality_clearance && data.document_clearance && data.inventory_reserved && data.coo_approval
  const status = cleared ? 'Cleared' : 'Blocked'
  const { error: updateError } = await supabase.from('dispatch').update({ dispatch_status: status }).eq('id', dispatch_id)
  return new Response(JSON.stringify({ dispatch_status: status, cleared, error: updateError?.message }), { headers: { 'Content-Type': 'application/json' }, status: updateError ? 400 : 200 })
})
