import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

serve(async (req) => {
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, serviceKey);
  const authHeader = req.headers.get('Authorization') || '';
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || req.headers.get('cf-connecting-ip') || req.headers.get('x-real-ip') || 'unknown';

  const { data: { user } } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''));
  if (!user) return new Response(JSON.stringify({ allowed: false, message: 'Unauthenticated request.' }), { status: 401 });

  const { data: appUser } = await supabase.from('users').select('id, role_name, ip_exempt, is_active').eq('auth_user_id', user.id).maybeSingle();
  if (!appUser?.is_active) return new Response(JSON.stringify({ allowed: false, message: 'Inactive MJ-DOS user.' }), { status: 403 });
  if (appUser.ip_exempt || appUser.role_name === 'CEO Admin') return new Response(JSON.stringify({ allowed: true, ip, message: 'IP exempt role.' }));

  const { data: network } = await supabase.from('office_networks').select('id').eq('public_ip', ip).eq('is_active', true).maybeSingle();
  const allowed = !!network;
  return new Response(JSON.stringify({ allowed, ip, message: allowed ? 'Approved office network.' : 'Employees must use the approved office network.' }), { headers: { 'Content-Type': 'application/json' }, status: allowed ? 200 : 403 });
});
