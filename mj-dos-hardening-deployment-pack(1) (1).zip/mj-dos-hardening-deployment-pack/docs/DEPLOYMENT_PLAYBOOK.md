# MJ-DOS Deployment Playbook

## 1. Supabase Auth

Enable Google provider:

- Supabase Dashboard → Authentication → Providers → Google
- Add Google Client ID and Secret
- Add redirect URL from Supabase Auth settings to Google Cloud Console

## 2. Database

Run SQL migrations from `supabase/migrations` in numerical order.

## 3. First CEO/Admin activation

After first login, run:

```sql
update public.users
set is_active = true, role_name = 'CEO Admin', ip_exempt = true
where email = 'junaidifzal09@gmail.com';
```

Change the email if another account is the initial admin.

## 4. Netlify deployment

- Connect GitHub repo to Netlify
- Build command: `npm run build`
- Publish directory: `dist`
- Add environment variables from `.env.example`

## 5. Vercel deployment

- Import GitHub repo to Vercel
- Framework preset: Vite
- Build command: `npm run build`
- Output directory: `dist`
- Add environment variables from `.env.example`

## 6. Office IP restriction

Recommended production method:

- Store approved office public IPs in `office_networks` table.
- On login and attendance actions, call Edge Function.
- Edge Function reads request IP from headers and validates against approved IP list.
- CEO/Admin may be exempted via `users.ip_exempt = true`.

Do not display the office IP on the public login page.
