# MJ-DOS ERP — Role-Based User Training Guide

## Purpose
This guide supports UAT and first-month rollout for MJ-DOS ERP. It is written for business users, not developers.

## CEO Admin
### Main responsibilities
- View all dashboards and reports.
- Approve Level 3 / strategic matters.
- Review audit log and compliance alerts.
- Activate users and assign roles.

### Daily workflow
1. Login with Google SSO.
2. Review CEO Dashboard: approvals, cash movement, dispatch, compliance and HR exceptions.
3. Open Approval Center and decide pending Level 3 approvals.
4. Review Audit Report for sensitive actions.
5. Generate board or management reports when required.

## CFO / Finance
### Main responsibilities
- Manage invoices, receipts, payments, expenses and ledgers.
- Verify financial matters before approval.
- Access P&L only where authorized.

### Critical restriction
Finance entries must not bypass approval or audit logging. No manual deletion is allowed; use archive workflow only.

## COO / Operations
### Main responsibilities
- Manage suppliers, procurement, purchase orders, inventory, quality and dispatch.
- Ensure dispatch is not released unless finance, document, inventory and quality clearance are complete.

### Dispatch rule
If the system shows `Dispatch blocked`, complete the missing items first. Do not create off-system dispatch instructions.

## Commercial / BD
### Main responsibilities
- Manage customers, quotations, sales orders, distributors and marketing campaigns.

### Critical restriction
Commercial users cannot create finance ledger entries or post stock movements.

## Compliance Officer
### Main responsibilities
- Maintain governance, contracts, SECP, FBR and regulatory records.
- Upload documents and monitor expiry dates.
- Review compliance approvals.

## HR/Admin
### Main responsibilities
- Manage employees, attendance, leave, discipline notices, appraisals, tasks and daily reports.

## Staff/User
### Main responsibilities
- Mark own attendance where allowed.
- Submit assigned tasks and daily reports.
- View own records only.

## Support checklist for users
Before reporting an issue, capture:
- Screenshot
- Date and time
- Role/user email
- Page/module name
- Action attempted
- Error message
