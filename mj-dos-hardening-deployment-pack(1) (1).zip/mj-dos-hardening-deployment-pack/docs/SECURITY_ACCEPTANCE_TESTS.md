# MJ-DOS ERP — Security Acceptance Tests

## 1. Authentication
- Verify login only works through Google SSO.
- Verify inactive users cannot access dashboard.
- Verify unknown users are created as inactive/pending approval.

## 2. Role-Based Access
Test every role against the authority matrix.
- CEO Admin: all modules.
- CFO: finance, approvals, reports.
- COO: operations, procurement, inventory, dispatch.
- Commercial: customers, quotations, sales pipeline only.
- Compliance: governance, SECP, FBR, contracts.
- HR/Admin: HR, attendance, tasks.
- Staff/User: own attendance, tasks and reports only.

## 3. RLS Boundary Tests
Run from the app and Supabase SQL testing environment:
- Commercial user cannot select `profit_loss`.
- Commercial user cannot insert into `ledger_entries`.
- Staff user cannot view other staff attendance.
- Staff user cannot view audit log.
- Non-document manager cannot archive documents.

## 4. Audit Immutability
Attempt:
```sql
update audit_log set action_type='tampered' limit 1;
delete from audit_log where true;
```
Expected: both fail.

## 5. No Hard Delete
Attempt delete from core tables:
```sql
delete from invoices where id = '<test-id>';
delete from documents where id = '<test-id>';
```
Expected: fail. Archive update should work only for permitted roles.

## 6. Dispatch Gate
Call `check_dispatch_readiness` before and after all clearance flags are true. Expected result:
- Missing flags: blocked with reasons.
- All flags true: ready.

## 7. Storage Security
- Bucket must be private.
- Public unauthenticated file URLs must not work.
- Signed download or authenticated download must work.

## 8. Secret Handling
- `service_role` key must not appear in frontend source or browser bundle.
- `.env` and `.env.local` must not be committed.
