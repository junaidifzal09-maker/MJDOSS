# LocalStorage MVP Migration Plan

The old MVP exports a JSON backup. Production migration should not allow direct restore by normal users.

## Safe migration path

1. Export backup from old browser MVP.
2. Review JSON manually.
3. Map keys to production tables.
4. Clean invalid statuses and duplicate references.
5. Import using a service-role-only script.
6. Create audit entry: `MIGRATION_IMPORT`.
7. Lock the migration file in document storage.

## Suggested mapping

- `approvals` → `approvals`
- `documents` → `documents` + Supabase Storage files
- `invoices` → `invoices`
- `receiptsPayments` or similar → `receipts_payments`
- `expenses` → `expenses`
- `ledger` → `ledger_entries`
- `procurement` → `procurement_requests`
- `purchaseOrders` → `purchase_orders`
- `inventory` → `inventory`
- `dispatch` → `dispatch`
- `qualityChecks` → `quality_checks`
- `customers` → `customers`
- `quotations` → `quotations`
- `salesOrders` → `sales_orders`
- `employees` → `employees`
- `attendance` → `attendance`
- `tasks` → `tasks`

## Rule

Migration is a controlled finance/governance event, not a user convenience feature.
