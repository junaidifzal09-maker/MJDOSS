# MJ-DOS ERP — Production Deployment & Validation Guide

This guide converts the MJ-DOS codebase from "code complete" to controlled production readiness. Production certification requires repository integration, Supabase migration execution, build testing, security validation, UAT, data migration, cutover, monitoring, and CEO/Admin sign-off.

## 1. Repository Setup

```bash
git init
git add .
git commit -m "Initial MJ-DOS ERP production codebase - phases 1-10"
git remote add origin https://github.com/mjagro/mj-dos-erp.git
git branch -M main
git push -u origin main
git checkout -b development && git push -u origin development
git checkout -b staging && git push -u origin staging
git checkout main
```

Verification:
- Repository is private.
- `.env`, `.env.local`, Supabase service-role keys, and database passwords are not committed.
- Branches exist: `main`, `staging`, `development`.

## 2. Supabase Project Configuration

Create project `mj-dos-erp-production`, preferably in the closest stable region to Pakistan/EU operations. Use a paid plan for production backup and PITR.

Apply migrations in this order:

1. `001_schema.sql`
2. `002_rls_audit.sql`
3. `003_storage.sql`
4. `004_seed_authority.sql`
5. `005_hardening_workflow.sql`
6. `006_reports.sql`
7. `007_attendance_network.sql`
8. `008_constraints_indexes.sql`
9. `009_seed_demo_data_optional.sql` — staging/UAT only

Use `scripts/verify_supabase.sql` after the migrations.

## 3. Google OAuth

Configure Google OAuth in Google Cloud and Supabase Auth.

Required redirect URL:

```txt
https://<project-ref>.supabase.co/auth/v1/callback
```

Supabase Auth settings must include the production frontend URL in Site URL and Redirect URLs.

## 4. Storage Bucket

Create or migrate via SQL bucket:

```txt
mj-dos-documents
```

Bucket must be private. Storage policies are included in `003_storage.sql`.

## 5. Local Frontend Test

```bash
npm install
cp .env.example .env.local
npm run dev
npm run build
npm run preview
```

Required `.env.local`:

```bash
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=xxxxx
```

## 6. Production Deployment

Recommended deployment: Vercel or Netlify.

Vercel settings:
- Framework: Vite
- Build command: `npm run build`
- Output directory: `dist`
- Env vars: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`

## 7. UAT Cases

Use `docs/UAT_TEST_MATRIX.csv` for sign-off.

Minimum UAT roles:
- CEO Admin
- CFO
- COO
- BD/Commercial
- Compliance Officer
- HR/Admin
- Staff/User

Critical cases:
- Google SSO login.
- First admin activation.
- Role-based UI and RLS blocking.
- Approval workflow Level 1–3.
- P&L restricted access.
- Document upload/download/archive.
- Dispatch blocking until finance, documents, inventory, quality, and COO clearance.
- Audit log creation and immutability.
- No hard delete.
- Reports load for authorized users.

## 8. Cutover

Pre-cutover:
- Export LocalStorage MVP data to JSON.
- Import into staging with `scripts/migrate_localstorage_to_supabase.mjs`.
- Reconcile counts per table.
- Freeze old MVP.

Cutover day:
- Final export/import.
- Verify data integrity.
- Enable production URL.
- Announce go-live.
- Monitor first working day closely.

## 9. Rollback

Frontend rollback:
- Use Vercel/Netlify prior deployment rollback.

Database rollback:
- Restore from Supabase backup or pre-cutover SQL dump.

Communications:
- Notify users immediately.
- Record incident in audit/governance log.

## 10. Certification Statement

MJ-DOS ERP is certified production-ready only after all items below are true:

- Database migrations executed cleanly.
- RLS tested by role.
- Google SSO works on production URL.
- Storage upload/download works.
- Audit log is immutable.
- No hard delete policy is enforced.
- Approval workflow tested end-to-end.
- Dispatch blocking tested.
- P&L restriction tested.
- UAT signed off.
- Backup and rollback tested.
- CEO/Admin formally approves go-live.
